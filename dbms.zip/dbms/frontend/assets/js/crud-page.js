document.addEventListener("DOMContentLoaded", async () => {
  if (!window.pageConfig) {
    return;
  }

  App.requireAuth();
  App.attachShell();

  const state = {
    records: [],
    filteredRecords: [],
    dependencies: {},
    page: 1,
    pageSize: 5,
    sortKey: window.pageConfig.defaultSort || "id",
    sortDir: "desc",
    editingId: null,
  };

  const modalElement = document.getElementById("recordModal");
  const modal = new bootstrap.Modal(modalElement);
  const form = document.getElementById("recordForm");
  const searchInput = document.getElementById("searchInput");
  const filterContainer = document.getElementById("filterContainer");
  const tableHead = document.getElementById("tableHead");
  const tableBody = document.getElementById("tableBody");
  const pagination = document.getElementById("pagination");
  const modalLabel = document.getElementById("recordModalLabel");
  const modalFields = document.getElementById("modalFields");

  async function loadDependencies() {
    for (const dependency of window.pageConfig.dependencies || []) {
      state.dependencies[dependency.name] = await App.api(dependency.endpoint);
    }
  }

  function getFieldOptions(field) {
    if (field.options) {
      return field.options;
    }

    if (!field.optionsSource) {
      return [];
    }

    return (state.dependencies[field.optionsSource] || []).map((item) => ({
      label: item[field.optionLabel || "name"] || item.full_name,
      value: item[field.optionValue || "id"],
    }));
  }

  function buildFilters() {
    filterContainer.innerHTML = (window.pageConfig.filters || []).map((filter) => {
      const options = getFieldOptions(filter).map((option) => `<option value="${option.value}">${option.label}</option>`).join("");
      return `
        <div class="col-md-3">
          <div class="form-floating">
            <select class="form-select js-filter" id="filter-${filter.name}" data-field="${filter.name}">
              <option value="">All</option>
              ${options}
            </select>
            <label for="filter-${filter.name}">${filter.label}</label>
          </div>
        </div>
      `;
    }).join("");

    document.querySelectorAll(".js-filter").forEach((element) => {
      element.addEventListener("change", applyFilters);
    });
  }

  function buildForm() {
    modalFields.innerHTML = window.pageConfig.fields.map((field) => {
      if (field.type === "select") {
        const options = getFieldOptions(field).map((option) => `<option value="${option.value}">${option.label}</option>`).join("");
        return `
          <div class="col-md-${field.col || 6}">
            <div class="form-floating">
              <select class="form-select" id="${field.name}" name="${field.name}" ${field.required ? "required" : ""}>
                <option value="">Select ${field.label}</option>
                ${options}
              </select>
              <label for="${field.name}">${field.label}</label>
            </div>
          </div>
        `;
      }

      if (field.type === "textarea") {
        return `
          <div class="col-12">
            <div class="form-floating">
              <textarea class="form-control" id="${field.name}" name="${field.name}" placeholder="${field.label}" style="height: 110px">${field.defaultValue || ""}</textarea>
              <label for="${field.name}">${field.label}</label>
            </div>
          </div>
        `;
      }

      return `
        <div class="col-md-${field.col || 6}">
          <div class="form-floating">
            <input class="form-control" id="${field.name}" name="${field.name}" type="${field.type || "text"}" placeholder="${field.label}" ${field.required ? "required" : ""}>
            <label for="${field.name}">${field.label}</label>
          </div>
        </div>
      `;
    }).join("");
  }

  function renderHeaders() {
    tableHead.innerHTML = `<tr>${window.pageConfig.columns.map((column) => `
      <th scope="col" class="${column.sortable !== false ? "cursor-pointer" : ""}" data-sort="${column.key}">
        ${column.label}
        ${state.sortKey === column.key ? `<i class="fa-solid fa-arrow-${state.sortDir === "asc" ? "up" : "down"} ms-1"></i>` : ""}
      </th>
    `).join("")}<th scope="col" class="text-end">Actions</th></tr>`;

    tableHead.querySelectorAll("[data-sort]").forEach((header) => {
      header.addEventListener("click", () => {
        const nextKey = header.dataset.sort;
        if (state.sortKey === nextKey) {
          state.sortDir = state.sortDir === "asc" ? "desc" : "asc";
        } else {
          state.sortKey = nextKey;
          state.sortDir = "asc";
        }
        applyFilters();
      });
    });
  }

  function sortRecords(records) {
    return [...records].sort((left, right) => {
      const a = left[state.sortKey];
      const b = right[state.sortKey];
      if (a === b) {
        return 0;
      }
      if (a === null || a === undefined || a === "") {
        return 1;
      }
      if (b === null || b === undefined || b === "") {
        return -1;
      }
      return state.sortDir === "asc"
        ? String(a).localeCompare(String(b), undefined, { numeric: true })
        : String(b).localeCompare(String(a), undefined, { numeric: true });
    });
  }

  function renderRows() {
    if (!state.filteredRecords.length) {
      tableBody.innerHTML = `<tr><td colspan="${window.pageConfig.columns.length + 1}">
        <div class="empty-state">
          <i class="fa-regular fa-folder-open fs-1 mb-3"></i>
          <div>No data found for the selected search/filter.</div>
        </div>
      </td></tr>`;
      pagination.innerHTML = "";
      return;
    }

    const result = App.paginate(state.filteredRecords, state.page, state.pageSize);
    state.page = result.currentPage;

    tableBody.innerHTML = result.pageItems.map((record) => `
      <tr>
        ${window.pageConfig.columns.map((column) => `<td>${column.render ? column.render(record) : (record[column.key] ?? "-")}</td>`).join("")}
        <td class="text-end">
          <button class="btn btn-outline-primary action-btn me-2 js-edit" data-id="${record.id}" title="Edit">
            <i class="fa-solid fa-pen"></i>
          </button>
          <button class="btn btn-outline-danger action-btn js-delete" data-id="${record.id}" title="Delete">
            <i class="fa-solid fa-trash"></i>
          </button>
        </td>
      </tr>
    `).join("");

    pagination.innerHTML = Array.from({ length: result.totalPages }, (_, index) => `
      <li class="page-item ${state.page === index + 1 ? "active" : ""}">
        <button class="page-link js-page" data-page="${index + 1}">${index + 1}</button>
      </li>
    `).join("");

    tableBody.querySelectorAll(".js-edit").forEach((button) => {
      button.addEventListener("click", () => openModal(Number(button.dataset.id)));
    });

    tableBody.querySelectorAll(".js-delete").forEach((button) => {
      button.addEventListener("click", () => removeRecord(Number(button.dataset.id)));
    });

    pagination.querySelectorAll(".js-page").forEach((button) => {
      button.addEventListener("click", () => {
        state.page = Number(button.dataset.page);
        renderRows();
      });
    });
  }

  function applyFilters() {
    const searchValue = searchInput.value.trim().toLowerCase();
    const filters = Object.fromEntries(
      Array.from(document.querySelectorAll(".js-filter")).map((element) => [element.dataset.field, element.value])
    );

    const filtered = state.records.filter((record) => {
      const matchesSearch = !searchValue || Object.values(record).some((value) =>
        String(value ?? "").toLowerCase().includes(searchValue)
      );

      const matchesFilters = Object.entries(filters).every(([field, value]) => {
        if (!value) {
          return true;
        }
        return String(record[field] ?? "") === value;
      });

      return matchesSearch && matchesFilters;
    });

    state.filteredRecords = sortRecords(filtered);
    state.page = 1;
    renderHeaders();
    renderRows();
  }

  function resetForm() {
    form.reset();
    form.classList.remove("was-validated");
    state.editingId = null;
  }

  function openModal(id = null) {
    resetForm();
    state.editingId = id;
    modalLabel.textContent = id ? `Edit ${window.pageConfig.title}` : `Add ${window.pageConfig.title}`;

    if (id) {
      const record = state.records.find((item) => item.id === id);
      window.pageConfig.fields.forEach((field) => {
        const input = document.getElementById(field.name);
        if (input) {
          input.value = record[field.name] ?? "";
        }
      });
    }

    modal.show();
  }

  async function fetchRecords() {
    state.records = await App.api(window.pageConfig.endpoint);
    applyFilters();
  }

  async function removeRecord(id) {
    if (!window.confirm("Delete this record?")) {
      return;
    }

    try {
      await App.api(`${window.pageConfig.endpoint}/${id}`, { method: "DELETE" });
      App.showToast(`${window.pageConfig.title} deleted successfully`);
      await fetchRecords();
    } catch (error) {
      App.showToast(error.message, "danger");
    }
  }

  searchInput.addEventListener("input", App.debounce(applyFilters, 200));

  document.getElementById("openAddModal").addEventListener("click", () => openModal());

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    if (!form.checkValidity()) {
      form.classList.add("was-validated");
      return;
    }

    const payload = Object.fromEntries(new FormData(form).entries());

    try {
      const method = state.editingId ? "PUT" : "POST";
      const url = state.editingId ? `${window.pageConfig.endpoint}/${state.editingId}` : window.pageConfig.endpoint;
      await App.api(url, { method, body: payload });
      App.showToast(`${window.pageConfig.title} saved successfully`);
      modal.hide();
      await fetchRecords();
    } catch (error) {
      App.showToast(error.message, "danger");
    }
  });

  await loadDependencies();
  buildFilters();
  buildForm();
  await fetchRecords();
});
