document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("loginForm");
  const demo = document.getElementById("demoCredentials");

  demo.addEventListener("click", () => {
    document.getElementById("username").value = "admin";
    document.getElementById("password").value = "admin123";
  });

  form.addEventListener("submit", async (event) => {
    event.preventDefault();

    if (!form.checkValidity()) {
      form.classList.add("was-validated");
      return;
    }

    try {
      const response = await App.api("/auth/login", {
        method: "POST",
        body: {
          username: document.getElementById("username").value.trim(),
          password: document.getElementById("password").value.trim(),
        },
      });
      App.setSession(response);
      App.showToast("Login successful");
      setTimeout(() => {
        location.href = "/index.html";
      }, 400);
    } catch (error) {
      App.showToast(error.message, "danger");
    }
  });
});
