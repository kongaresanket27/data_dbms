document.addEventListener("DOMContentLoaded", async () => {
  App.requireAuth();
  App.attachShell();

  try {
    const stats = await App.api("/dashboard/stats");
    document.getElementById("statEmployees").textContent = stats.totalEmployees;
    document.getElementById("statAssets").textContent = stats.totalAssets;
    document.getElementById("statDepartments").textContent = stats.totalDepartments;
    document.getElementById("statMaintenance").textContent = stats.pendingMaintenance;
  } catch (error) {
    App.showToast(error.message, "danger");
  }
});
