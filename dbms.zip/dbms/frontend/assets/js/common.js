window.App = (() => {
  const state = {
    loaderCount: 0,
  };

  function getToken() {
    return localStorage.getItem("ams_token");
  }

  function getUser() {
    const raw = localStorage.getItem("ams_user");
    return raw ? JSON.parse(raw) : null;
  }

  function setSession(payload) {
    localStorage.setItem("ams_token", payload.token);
    localStorage.setItem("ams_user", JSON.stringify(payload.user));
  }

  function clearSession() {
    localStorage.removeItem("ams_token");
    localStorage.removeItem("ams_user");
  }

  function showLoader(show) {
    const loader = document.getElementById("loadingOverlay");
    if (!loader) {
      return;
    }

    state.loaderCount = Math.max(0, state.loaderCount + (show ? 1 : -1));
    loader.classList.toggle("show", state.loaderCount > 0);
  }

  function showToast(message, type = "success") {
    const container = document.getElementById("toastContainer");
    if (!container) {
      return;
    }

    const toast = document.createElement("div");
    toast.className = `toast align-items-center text-bg-${type} border-0`;
    toast.role = "alert";
    toast.innerHTML = `
      <div class="d-flex">
        <div class="toast-body">${message}</div>
        <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
      </div>
    `;
    container.appendChild(toast);
    const bsToast = new bootstrap.Toast(toast, { delay: 2500 });
    bsToast.show();
    toast.addEventListener("hidden.bs.toast", () => toast.remove());
  }

  async function api(path, options = {}) {
    showLoader(true);
    try {
      const config = {
        method: options.method || "GET",
        headers: {
          "Content-Type": "application/json",
          ...(getToken() ? { "x-auth-token": getToken() } : {}),
          ...(options.headers || {}),
        },
      };

      if (options.body) {
        config.body = JSON.stringify(options.body);
      }

      const response = await fetch(path, config);
      const data = await response.json().catch(() => ({}));

      if (!response.ok) {
        const message = data.message || "Request failed";
        if (response.status === 401) {
          clearSession();
          if (!location.pathname.endsWith("login.html")) {
            location.href = "/login.html";
          }
        }
        throw new Error(message);
      }

      return data;
    } finally {
      showLoader(false);
    }
  }

  function requireAuth() {
    if (!getToken()) {
      location.href = "/login.html";
    }
  }

  function attachShell() {
    document.querySelectorAll("[data-logout]").forEach((button) => {
      button.addEventListener("click", () => {
        clearSession();
        location.href = "/login.html";
      });
    });

    const user = getUser();
    document.querySelectorAll("[data-user-name]").forEach((element) => {
      element.textContent = user ? user.full_name : "Guest";
    });
  }

  function statusBadge(status) {
    const map = {
      Active: "success",
      Available: "success",
      Completed: "success",
      Assigned: "primary",
      Pending: "warning",
      "In Progress": "info",
      Maintenance: "danger",
      Retired: "secondary",
      Inactive: "secondary",
      Busy: "warning",
      "On Leave": "warning",
    };

    const color = map[status] || "secondary";
    return `<span class="badge text-bg-${color}">${status}</span>`;
  }

  function debounce(fn, delay = 250) {
    let timer = null;
    return (...args) => {
      clearTimeout(timer);
      timer = setTimeout(() => fn(...args), delay);
    };
  }

  function paginate(items, page, pageSize) {
    const totalPages = Math.max(1, Math.ceil(items.length / pageSize));
    const currentPage = Math.min(page, totalPages);
    const start = (currentPage - 1) * pageSize;
    return {
      currentPage,
      totalPages,
      pageItems: items.slice(start, start + pageSize),
    };
  }

  return {
    api,
    attachShell,
    clearSession,
    debounce,
    getToken,
    getUser,
    paginate,
    requireAuth,
    setSession,
    showLoader,
    showToast,
    statusBadge,
  };
})();
