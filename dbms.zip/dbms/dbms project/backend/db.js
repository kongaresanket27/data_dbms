const state = {
  nextDepartmentId: 1,
  nextEmployeeId: 1,
  nextAssetId: 1,
  nextTechnicianId: 1,
  nextMaintenanceId: 1,
  departments: [],
  employees: [],
  assets: [],
  technicians: [],
  assignments: [],
  maintenance: [],
};

function isPositiveInteger(value) {
  return Number.isInteger(value) && value > 0;
}

function addDepartment(name) {
  const department = {
    dept_id: state.nextDepartmentId++,
    dept_name: name,
  };
  state.departments.push(department);
  return department;
}

function addEmployee(name, deptId) {
  const employee = {
    emp_id: state.nextEmployeeId++,
    emp_name: name,
    dept_id: deptId,
  };
  state.employees.push(employee);
  return employee;
}

function addAsset(name, type, status, locationId) {
  const asset = {
    asset_id: state.nextAssetId++,
    asset_name: name,
    asset_type: type,
    asset_status: status,
    location_id: locationId,
  };
  state.assets.push(asset);
  return asset;
}

function addTechnician(name) {
  const technician = {
    tech_id: state.nextTechnicianId++,
    tech_name: name,
  };
  state.technicians.push(technician);
  return technician;
}

function addAssignment(empId, assetId) {
  const assignment = {
    emp_id: empId,
    asset_id: assetId,
    assigned_at: new Date().toISOString(),
  };
  state.assignments.push(assignment);
  return assignment;
}

function addMaintenance(empId, assetId, techId, status) {
  const record = {
    maintenance_id: state.nextMaintenanceId++,
    emp_id: empId,
    asset_id: assetId,
    tech_id: techId,
    status,
  };
  state.maintenance.push(record);
  return record;
}

module.exports = {
  state,
  isPositiveInteger,
  addDepartment,
  addEmployee,
  addAsset,
  addTechnician,
  addAssignment,
  addMaintenance,
};
