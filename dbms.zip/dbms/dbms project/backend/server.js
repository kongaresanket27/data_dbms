const path = require("path");
const express = require("../../backend/node_modules/express");
const cors = require("../../backend/node_modules/cors");
const {
  state,
  isPositiveInteger,
  addDepartment,
  addEmployee,
  addAsset,
  addTechnician,
  addAssignment,
  addMaintenance,
} = require("./db");

const app = express();
const PORT = 3000;
const staticDir = path.resolve(__dirname, "..");

app.use(cors());
app.use(express.json());
app.use(express.static(staticDir));

function requireFields(body, fields) {
  const missing = fields.filter((field) => {
    const value = body[field];
    return value === undefined || value === null || String(value).trim() === "";
  });

  return missing;
}

function parsePositiveInteger(value) {
  const parsed = Number(value);
  return isPositiveInteger(parsed) ? parsed : null;
}

app.get("/", (_req, res) => {
  res.sendFile(path.join(staticDir, "index.html"));
});

app.get("/health", (_req, res) => {
  res.json({ ok: true });
});

app.get("/employees", (_req, res) => {
  res.json(state.employees);
});

app.get("/departments", (_req, res) => {
  res.json(state.departments);
});

app.get("/assets", (_req, res) => {
  res.json(state.assets);
});

app.get("/technicians", (_req, res) => {
  res.json(state.technicians);
});

app.get("/assignments", (_req, res) => {
  res.json(state.assignments);
});

app.get("/maintenance", (_req, res) => {
  res.json(state.maintenance);
});

app.post("/addDepartment", (req, res) => {
  const missing = requireFields(req.body, ["name"]);
  if (missing.length > 0) {
    return res.status(400).send(`Missing fields: ${missing.join(", ")}`);
  }

  const department = addDepartment(String(req.body.name).trim());
  return res.send(`Department added with ID ${department.dept_id}`);
});

app.post("/addEmployee", (req, res) => {
  const missing = requireFields(req.body, ["name", "dept_id"]);
  if (missing.length > 0) {
    return res.status(400).send(`Missing fields: ${missing.join(", ")}`);
  }

  const deptId = parsePositiveInteger(req.body.dept_id);
  if (!deptId) {
    return res.status(400).send("Department ID must be a positive number");
  }

  const employee = addEmployee(
    String(req.body.name).trim(),
    deptId
  );
  return res.send(`Employee added with ID ${employee.emp_id}`);
});

app.post("/addAsset", (req, res) => {
  const missing = requireFields(req.body, ["name", "type", "status", "location_id"]);
  if (missing.length > 0) {
    return res.status(400).send(`Missing fields: ${missing.join(", ")}`);
  }

  const locationId = parsePositiveInteger(req.body.location_id);
  if (!locationId) {
    return res.status(400).send("Location ID must be a positive number");
  }

  const asset = addAsset(
    String(req.body.name).trim(),
    String(req.body.type).trim(),
    String(req.body.status).trim(),
    locationId
  );
  return res.send(`Asset added with ID ${asset.asset_id}`);
});

app.post("/addTechnician", (req, res) => {
  const missing = requireFields(req.body, ["name"]);
  if (missing.length > 0) {
    return res.status(400).send(`Missing fields: ${missing.join(", ")}`);
  }

  const technician = addTechnician(String(req.body.name).trim());
  return res.send(`Technician added with ID ${technician.tech_id}`);
});

app.post("/assignAsset", (req, res) => {
  const missing = requireFields(req.body, ["emp_id", "asset_id"]);
  if (missing.length > 0) {
    return res.status(400).send(`Missing fields: ${missing.join(", ")}`);
  }

  const empId = parsePositiveInteger(req.body.emp_id);
  const assetId = parsePositiveInteger(req.body.asset_id);
  if (!empId || !assetId) {
    return res.status(400).send("Employee ID and Asset ID must be positive numbers");
  }

  addAssignment(empId, assetId);
  return res.send("Asset assigned successfully");
});

app.post("/addMaintenance", (req, res) => {
  const missing = requireFields(req.body, ["emp_id", "asset_id", "tech_id", "status"]);
  if (missing.length > 0) {
    return res.status(400).send(`Missing fields: ${missing.join(", ")}`);
  }

  const empId = parsePositiveInteger(req.body.emp_id);
  const assetId = parsePositiveInteger(req.body.asset_id);
  const techId = parsePositiveInteger(req.body.tech_id);
  if (!empId || !assetId || !techId) {
    return res.status(400).send("Employee ID, Asset ID, and Technician ID must be positive numbers");
  }

  const record = addMaintenance(
    empId,
    assetId,
    techId,
    String(req.body.status).trim()
  );
  return res.send(`Maintenance recorded with ID ${record.maintenance_id}`);
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
