# Quick Start Guide - Asset Management System

## Prerequisites
- Node.js (v14 or higher)
- npm (comes with Node.js)
- Browser (Chrome, Firefox, Safari, Edge)

## Step 1: Install Dependencies
```bash
cd backend
npm install
```

## Step 2: Start the Server
```bash
node server.js
```

You should see:
```
Server running on port 3000
Application available at http://localhost:3000
Database status: Mock data mode
```

## Step 3: Open in Browser
Navigate to: **http://localhost:3000**

You will be redirected to the login page.

## Step 4: Login
Use the demo credentials:
- **Username:** `admin`
- **Password:** `admin123`

Click "Use Demo" button to auto-fill credentials.

## Step 5: Explore the System

### Dashboard
- View system statistics (employees, assets, departments, pending maintenance)
- Access quick navigation buttons

### Employee Management
- View all employees with department and status
- Search employees by name, email, or phone
- Filter by status (Active, Inactive, On Leave) or department
- Add new employee
- Edit employee details
- Delete employee (automatically updates asset assignments)

### Asset Management
- Track all company assets
- Search and filter by status (Available, Assigned, Maintenance, Retired) or type (Laptop, Desktop, Printer, Accessory)
- Assign assets to employees when creating/editing
- Monitor asset status in real-time

### Department Management
- View all departments and employee count
- Filter departments by status
- Add new department with manager assignment
- Edit department details
- Delete department (reassigns employees)

### Technician Management
- Manage technical support staff
- Track technician availability (Active, Busy, Inactive)
- View specialization (Hardware, Networking, Software)
- Add, edit, or delete technicians

### Maintenance Tracking
- Monitor asset maintenance requests
- Assign technicians to maintenance tickets
- Track request status (Pending, In Progress, Completed)
- Add notes for each maintenance request

## Features

### Search & Filter
- Real-time search with 200ms debounce
- Multi-criteria filtering
- Column sorting (click column headers)
- Pagination (5 items per page)

### CRUD Operations
- **Create**: Click "Add [Entity]" button to open form
- **Read**: View all records in table
- **Update**: Click pencil icon to edit
- **Delete**: Click trash icon to remove

### Notifications
- Success toasts after operations
- Error highlights on form validation
- Loading overlay during API calls

## Sample Data

The system includes realistic sample data:
- 4 Employees across 3 departments
- 4 Assets with various statuses
- 3 Technicians with different specializations
- 3 Maintenance records in different stages

## API Endpoints

All endpoints require authentication with `x-auth-token` header.

```bash
# Authentication
POST   /auth/login
GET    /auth/health

# Dashboard
GET    /dashboard/stats

# Departments (CRUD)
GET    /departments
POST   /departments
PUT    /departments/:id
DELETE /departments/:id

# Employees (CRUD)
GET    /employees
POST   /employees
PUT    /employees/:id
DELETE /employees/:id

# Assets (CRUD)
GET    /assets
POST   /assets
PUT    /assets/:id
DELETE /assets/:id

# Technicians (CRUD)
GET    /technicians
POST   /technicians
PUT    /technicians/:id
DELETE /technicians/:id

# Maintenance (CRUD)
GET    /maintenance
POST   /maintenance
PUT    /maintenance/:id
DELETE /maintenance/:id
```

## MySQL Configuration (Optional)

By default, the system uses mock data. To use MySQL:

1. Create a file `.env` in the `backend` directory:
```
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=your_mysql_password
DB_NAME=asset_management_system
USE_MOCK_DB=false
```

2. Import the schema:
```bash
mysql -u root -p asset_management_system < backend/sql/schema.sql
```

3. Restart the server:
```bash
node server.js
```

## Troubleshooting

### Port 3000 already in use?
```bash
# Linux/Mac
lsof -i :3000
kill -9 <PID>

# Windows
netstat -ano | findstr :3000
taskkill /PID <PID> /F
```

### Login not working?
- Verify server is running (check terminal output)
- Clear browser cache and localStorage
- Check that `common.js` and `login.js` are loaded

### Database connection failed?
- Check MySQL is running
- Verify credentials in `.env` file
- Ensure database exists: `CREATE DATABASE asset_management_system;`

### Page shows no data?
- Check browser console for errors (F12)
- Verify API calls in Network tab
- Check server terminal for error messages

## File Locations

- **Frontend Pages:** `frontend/`
- **Backend API:** `backend/server.js`
- **Database Schema:** `backend/sql/schema.sql`
- **Configuration:** `backend/.env` (create if using MySQL)
- **Mock Data:** `backend/config/mockStore.js`

## Support

For issues or questions, check:
1. Browser console (F12 → Console)
2. Server terminal output
3. Network tab (F12 → Network) to see API calls
4. README.md in project root

---

**Happy coding! 🚀**
