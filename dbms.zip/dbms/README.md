# Asset Management System

Modern full-stack college project using:

- Frontend: HTML, Bootstrap 5, JavaScript
- Backend: Node.js, Express
- Database: MySQL-ready schema with mock-data fallback

## Project Structure

- `frontend/` : modern responsive UI pages
- `backend/` : routes, controllers, config, services, and SQL schema

## Quick Start

1. Open a terminal in `backend/`
2. Run `npm start`
3. Open `http://localhost:3000`
4. Login with:
   - Username: `admin`
   - Password: `admin123`

## MySQL Setup

1. Import `backend/sql/schema.sql` into MySQL
2. Copy `backend/.env.example` values into your environment
3. Set `USE_MOCK_DB=false`
4. Restart the backend

By default, the project runs in mock-data mode so it is easy to demonstrate even before MySQL is configured.
