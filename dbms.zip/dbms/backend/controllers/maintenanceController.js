const {
  getMaintenance,
  createMaintenance,
  updateMaintenance,
  deleteMaintenance,
} = require("../services/dataService");

async function listMaintenance(_req, res, next) {
  try {
    res.status(200).json(await getMaintenance());
  } catch (error) {
    next(error);
  }
}

async function addMaintenance(req, res, next) {
  try {
    const { asset_id, technician_id, request_date, scheduled_date, status, notes } = req.body;
    if (!asset_id || !technician_id || !request_date || !scheduled_date || !status) {
      return res.status(400).json({ message: "Asset, technician, request date, scheduled date, and status are required" });
    }
    res.status(201).json(await createMaintenance({
      asset_id: Number(asset_id),
      technician_id: Number(technician_id),
      request_date,
      scheduled_date,
      status,
      notes: notes || "",
    }));
  } catch (error) {
    next(error);
  }
}

async function editMaintenance(req, res, next) {
  try {
    const item = await updateMaintenance(Number(req.params.id), {
      asset_id: Number(req.body.asset_id),
      technician_id: Number(req.body.technician_id),
      request_date: req.body.request_date,
      scheduled_date: req.body.scheduled_date,
      status: req.body.status,
      notes: req.body.notes || "",
    });
    if (!item) {
      return res.status(404).json({ message: "Maintenance record not found" });
    }
    res.status(200).json(item);
  } catch (error) {
    next(error);
  }
}

async function removeMaintenance(req, res, next) {
  try {
    const deleted = await deleteMaintenance(Number(req.params.id));
    if (!deleted) {
      return res.status(404).json({ message: "Maintenance record not found" });
    }
    res.status(200).json({ message: "Maintenance record deleted successfully" });
  } catch (error) {
    next(error);
  }
}

module.exports = {
  addMaintenance,
  editMaintenance,
  listMaintenance,
  removeMaintenance,
};
