const {
  getDepartments,
  createDepartment,
  updateDepartment,
  deleteDepartment,
} = require("../services/dataService");

async function listDepartments(_req, res, next) {
  try {
    res.status(200).json(await getDepartments());
  } catch (error) {
    next(error);
  }
}

async function addDepartment(req, res, next) {
  try {
    const { name, code, manager_name, status } = req.body;
    if (!name || !code || !manager_name || !status) {
      return res.status(400).json({ message: "All fields are required" });
    }
    res.status(201).json(await createDepartment({ name, code, manager_name, status }));
  } catch (error) {
    next(error);
  }
}

async function editDepartment(req, res, next) {
  try {
    const item = await updateDepartment(Number(req.params.id), req.body);
    if (!item) {
      return res.status(404).json({ message: "Department not found" });
    }
    res.status(200).json(item);
  } catch (error) {
    next(error);
  }
}

async function removeDepartment(req, res, next) {
  try {
    const deleted = await deleteDepartment(Number(req.params.id));
    if (!deleted) {
      return res.status(404).json({ message: "Department not found" });
    }
    res.status(200).json({ message: "Department deleted successfully" });
  } catch (error) {
    next(error);
  }
}

module.exports = {
  addDepartment,
  editDepartment,
  listDepartments,
  removeDepartment,
};
