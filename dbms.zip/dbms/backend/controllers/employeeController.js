const {
  getEmployees,
  createEmployee,
  updateEmployee,
  deleteEmployee,
} = require("../services/dataService");

async function listEmployees(_req, res, next) {
  try {
    res.status(200).json(await getEmployees());
  } catch (error) {
    next(error);
  }
}

async function addEmployee(req, res, next) {
  try {
    const { full_name, email, phone, department_id, status } = req.body;
    if (!full_name || !email || !phone || !department_id || !status) {
      return res.status(400).json({ message: "All fields are required" });
    }

    const item = await createEmployee({
      full_name,
      email,
      phone,
      department_id: Number(department_id),
      status,
    });
    res.status(201).json(item);
  } catch (error) {
    next(error);
  }
}

async function editEmployee(req, res, next) {
  try {
    const item = await updateEmployee(Number(req.params.id), {
      full_name: req.body.full_name,
      email: req.body.email,
      phone: req.body.phone,
      department_id: Number(req.body.department_id),
      status: req.body.status,
    });
    if (!item) {
      return res.status(404).json({ message: "Employee not found" });
    }
    res.status(200).json(item);
  } catch (error) {
    next(error);
  }
}

async function removeEmployee(req, res, next) {
  try {
    const deleted = await deleteEmployee(Number(req.params.id));
    if (!deleted) {
      return res.status(404).json({ message: "Employee not found" });
    }
    res.status(200).json({ message: "Employee deleted successfully" });
  } catch (error) {
    next(error);
  }
}

module.exports = {
  addEmployee,
  editEmployee,
  listEmployees,
  removeEmployee,
};
