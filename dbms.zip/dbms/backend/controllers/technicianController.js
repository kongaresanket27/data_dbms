const {
  getTechnicians,
  createTechnician,
  updateTechnician,
  deleteTechnician,
} = require("../services/dataService");

async function listTechnicians(_req, res, next) {
  try {
    res.status(200).json(await getTechnicians());
  } catch (error) {
    next(error);
  }
}

async function addTechnician(req, res, next) {
  try {
    const { full_name, email, phone, specialization, status } = req.body;
    if (!full_name || !email || !phone || !specialization || !status) {
      return res.status(400).json({ message: "All fields are required" });
    }
    res.status(201).json(await createTechnician({ full_name, email, phone, specialization, status }));
  } catch (error) {
    next(error);
  }
}

async function editTechnician(req, res, next) {
  try {
    const item = await updateTechnician(Number(req.params.id), req.body);
    if (!item) {
      return res.status(404).json({ message: "Technician not found" });
    }
    res.status(200).json(item);
  } catch (error) {
    next(error);
  }
}

async function removeTechnician(req, res, next) {
  try {
    const deleted = await deleteTechnician(Number(req.params.id));
    if (!deleted) {
      return res.status(404).json({ message: "Technician not found" });
    }
    res.status(200).json({ message: "Technician deleted successfully" });
  } catch (error) {
    next(error);
  }
}

module.exports = {
  addTechnician,
  editTechnician,
  listTechnicians,
  removeTechnician,
};
