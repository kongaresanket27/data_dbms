const { getDashboardStats } = require("../services/dataService");

async function getStats(_req, res, next) {
  try {
    res.status(200).json(await getDashboardStats());
  } catch (error) {
    next(error);
  }
}

module.exports = {
  getStats,
};
