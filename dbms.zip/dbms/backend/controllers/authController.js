const { authenticateUser } = require("../services/dataService");
const { issueToken } = require("../middleware/authMiddleware");

async function login(req, res, next) {
  try {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({ message: "Username and password are required" });
    }

    const user = await authenticateUser(username, password);
    if (!user) {
      return res.status(401).json({ message: "Invalid credentials" });
    }

    const token = issueToken(user);
    res.status(200).json({
      message: "Login successful",
      token,
      user: {
        id: user.id,
        username: user.username,
        full_name: user.full_name,
        role: user.role,
      },
    });
  } catch (error) {
    next(error);
  }
}

function health(_req, res) {
  res.status(200).json({ ok: true });
}

module.exports = {
  health,
  login,
};
