const {
  getAssets,
  createAsset,
  updateAsset,
  deleteAsset,
} = require("../services/dataService");

async function listAssets(_req, res, next) {
  try {
    res.status(200).json(await getAssets());
  } catch (error) {
    next(error);
  }
}

async function addAsset(req, res, next) {
  try {
    const { name, asset_tag, type, status, assigned_employee_id, purchase_date } = req.body;
    if (!name || !asset_tag || !type || !status || !purchase_date) {
      return res.status(400).json({ message: "Name, asset tag, type, status, and purchase date are required" });
    }

    const item = await createAsset({
      name,
      asset_tag,
      type,
      status,
      assigned_employee_id: assigned_employee_id ? Number(assigned_employee_id) : null,
      purchase_date,
    });
    res.status(201).json(item);
  } catch (error) {
    next(error);
  }
}

async function editAsset(req, res, next) {
  try {
    const item = await updateAsset(Number(req.params.id), {
      name: req.body.name,
      asset_tag: req.body.asset_tag,
      type: req.body.type,
      status: req.body.status,
      assigned_employee_id: req.body.assigned_employee_id ? Number(req.body.assigned_employee_id) : null,
      purchase_date: req.body.purchase_date,
    });
    if (!item) {
      return res.status(404).json({ message: "Asset not found" });
    }
    res.status(200).json(item);
  } catch (error) {
    next(error);
  }
}

async function removeAsset(req, res, next) {
  try {
    const deleted = await deleteAsset(Number(req.params.id));
    if (!deleted) {
      return res.status(404).json({ message: "Asset not found" });
    }
    res.status(200).json({ message: "Asset deleted successfully" });
  } catch (error) {
    next(error);
  }
}

module.exports = {
  addAsset,
  editAsset,
  listAssets,
  removeAsset,
};
