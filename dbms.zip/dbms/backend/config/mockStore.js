const state = {
  counters: {
    departments: 3,
    employees: 4,
    assets: 4,
    technicians: 3,
    maintenance: 3,
  },
  users: [
    {
      id: 1,
      username: "admin",
      password: "admin123",
      full_name: "Admin User",
      role: "Administrator",
    },
  ],
  departments: [
    { id: 1, name: "IT", code: "IT", manager_name: "Priya", status: "Active", created_at: "2026-04-01" },
    { id: 2, name: "HR", code: "HR", manager_name: "Rahul", status: "Active", created_at: "2026-04-02" },
    { id: 3, name: "Finance", code: "FIN", manager_name: "Neha", status: "Active", created_at: "2026-04-03" },
  ],
  employees: [
    { id: 1, full_name: "Aman Verma", email: "aman@example.com", phone: "9876543210", department_id: 1, status: "Active", created_at: "2026-04-04" },
    { id: 2, full_name: "Kiran Shah", email: "kiran@example.com", phone: "9876543211", department_id: 2, status: "Active", created_at: "2026-04-05" },
    { id: 3, full_name: "Riya Das", email: "riya@example.com", phone: "9876543212", department_id: 1, status: "On Leave", created_at: "2026-04-06" },
    { id: 4, full_name: "Sohan Patel", email: "sohan@example.com", phone: "9876543213", department_id: 3, status: "Active", created_at: "2026-04-07" },
  ],
  assets: [
    { id: 1, name: "Dell Latitude", asset_tag: "AST-1001", type: "Laptop", status: "Assigned", assigned_employee_id: 1, purchase_date: "2026-03-01", created_at: "2026-04-04" },
    { id: 2, name: "HP ProDesk", asset_tag: "AST-1002", type: "Desktop", status: "Available", assigned_employee_id: null, purchase_date: "2026-03-02", created_at: "2026-04-04" },
    { id: 3, name: "Canon Printer", asset_tag: "AST-1003", type: "Printer", status: "Maintenance", assigned_employee_id: null, purchase_date: "2026-03-05", created_at: "2026-04-05" },
    { id: 4, name: "MacBook Air", asset_tag: "AST-1004", type: "Laptop", status: "Assigned", assigned_employee_id: 3, purchase_date: "2026-03-07", created_at: "2026-04-06" },
  ],
  technicians: [
    { id: 1, full_name: "Vikas Kumar", email: "vikas@example.com", phone: "9000000001", specialization: "Hardware", status: "Active", created_at: "2026-04-04" },
    { id: 2, full_name: "Sara Ali", email: "sara@example.com", phone: "9000000002", specialization: "Networking", status: "Active", created_at: "2026-04-05" },
    { id: 3, full_name: "Tina Roy", email: "tina@example.com", phone: "9000000003", specialization: "Software", status: "Busy", created_at: "2026-04-06" },
  ],
  maintenance: [
    { id: 1, asset_id: 3, technician_id: 1, request_date: "2026-04-08", scheduled_date: "2026-04-12", status: "Pending", notes: "Paper feed issue", created_at: "2026-04-08" },
    { id: 2, asset_id: 1, technician_id: 3, request_date: "2026-04-07", scheduled_date: "2026-04-09", status: "Completed", notes: "OS reinstall", created_at: "2026-04-07" },
    { id: 3, asset_id: 4, technician_id: 2, request_date: "2026-04-09", scheduled_date: "2026-04-13", status: "In Progress", notes: "Wi-Fi adapter issue", created_at: "2026-04-09" },
  ],
};

function getNextId(key) {
  state.counters[key] += 1;
  return state.counters[key];
}

module.exports = {
  state,
  getNextId,
};
