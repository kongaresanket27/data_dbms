const mysql = require("mysql2/promise");

let pool = null;
let mockMode = true;

function getConfig() {
  return {
    host: process.env.DB_HOST || "localhost",
    port: Number(process.env.DB_PORT || 3306),
    user: process.env.DB_USER || "root",
    password: process.env.DB_PASSWORD || "",
    database: process.env.DB_NAME || "asset_management_system",
  };
}

async function initDatabase() {
  const forceMock = process.env.USE_MOCK_DB !== "false";
  if (forceMock) {
    mockMode = true;
    return;
  }

  try {
    pool = mysql.createPool({
      ...getConfig(),
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0,
    });
    await pool.query("SELECT 1");
    mockMode = false;
    console.log("Database Connected");
  } catch (error) {
    pool = null;
    mockMode = true;
    console.warn("MySQL connection failed. Falling back to mock data mode.");
    console.warn(error.message);
  }
}

function getPool() {
  return pool;
}

function usingMockDatabase() {
  return mockMode;
}

module.exports = {
  getConfig,
  getPool,
  initDatabase,
  usingMockDatabase,
};
