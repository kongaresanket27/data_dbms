const path = require("path");
const express = require("express");
const cors = require("cors");
const { initDatabase, usingMockDatabase } = require("./config/db");
const authRoutes = require("./routes/authRoutes");
const dashboardRoutes = require("./routes/dashboardRoutes");
const departmentRoutes = require("./routes/departmentRoutes");
const employeeRoutes = require("./routes/employeeRoutes");
const assetRoutes = require("./routes/assetRoutes");
const technicianRoutes = require("./routes/technicianRoutes");
const maintenanceRoutes = require("./routes/maintenanceRoutes");
const { authenticate } = require("./middleware/authMiddleware");
const { errorHandler } = require("./middleware/errorHandler");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const frontendDir = path.resolve(__dirname, "..", "frontend");

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(frontendDir));

app.get("/", (_req, res) => {
  res.sendFile(path.join(frontendDir, "login.html"));
});

app.use("/auth", authRoutes);
app.use(authenticate);
app.use("/dashboard", dashboardRoutes);
app.use("/departments", departmentRoutes);
app.use("/employees", employeeRoutes);
app.use("/assets", assetRoutes);
app.use("/technicians", technicianRoutes);
app.use("/maintenance", maintenanceRoutes);

app.use((req, res) => {
  res.status(404).json({ message: `Route not found: ${req.method} ${req.originalUrl}` });
});

app.use(errorHandler);

async function startServer() {
  await initDatabase();
  app.listen(PORT, () => {
    const mode = usingMockDatabase() ? "Mock data mode" : "MySQL mode";
    console.log(`Server running on port ${PORT}`);
    console.log(`Application available at http://localhost:${PORT}`);
    console.log(`Database status: ${mode}`);
  });
}

startServer().catch((error) => {
  console.error("Failed to start server", error);
  process.exit(1);
});
