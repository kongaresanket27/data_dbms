const { getPool, usingMockDatabase } = require("../config/db");
const { state, getNextId } = require("../config/mockStore");

function sortByCreatedDesc(items) {
  return [...items].sort((a, b) => new Date(b.created_at || 0) - new Date(a.created_at || 0));
}

function enrichDepartment(department) {
  const employeeCount = state.employees.filter((employee) => employee.department_id === department.id).length;
  return { ...department, employee_count: employeeCount };
}

function enrichEmployee(employee) {
  const department = state.departments.find((item) => item.id === employee.department_id);
  return { ...employee, department_name: department ? department.name : "Unassigned" };
}

function enrichAsset(asset) {
  const employee = state.employees.find((item) => item.id === asset.assigned_employee_id);
  return { ...asset, assigned_employee_name: employee ? employee.full_name : "Unassigned" };
}

function enrichMaintenance(record) {
  const asset = state.assets.find((item) => item.id === record.asset_id);
  const technician = state.technicians.find((item) => item.id === record.technician_id);
  return {
    ...record,
    asset_name: asset ? asset.name : "Unknown asset",
    technician_name: technician ? technician.full_name : "Unknown technician",
  };
}

async function getDashboardStats() {
  if (usingMockDatabase()) {
    return {
      totalEmployees: state.employees.length,
      totalAssets: state.assets.length,
      totalDepartments: state.departments.length,
      pendingMaintenance: state.maintenance.filter((item) => item.status === "Pending").length,
    };
  }

  const pool = getPool();
  const [employees] = await pool.query("SELECT COUNT(*) AS count FROM employees");
  const [assets] = await pool.query("SELECT COUNT(*) AS count FROM assets");
  const [departments] = await pool.query("SELECT COUNT(*) AS count FROM departments");
  const [maintenance] = await pool.query("SELECT COUNT(*) AS count FROM maintenance WHERE status = 'Pending'");

  return {
    totalEmployees: employees[0].count,
    totalAssets: assets[0].count,
    totalDepartments: departments[0].count,
    pendingMaintenance: maintenance[0].count,
  };
}

async function authenticateUser(username, password) {
  if (usingMockDatabase()) {
    return state.users.find((user) => user.username === username && user.password === password) || null;
  }

  const pool = getPool();
  const [rows] = await pool.query(
    "SELECT id, username, password, full_name, role FROM users WHERE username = ? LIMIT 1",
    [username]
  );

  if (!rows[0] || rows[0].password !== password) {
    return null;
  }

  return rows[0];
}

async function getDepartments() {
  if (usingMockDatabase()) {
    return sortByCreatedDesc(state.departments.map(enrichDepartment));
  }

  const pool = getPool();
  const [rows] = await pool.query(`
    SELECT d.id, d.name, d.code, d.manager_name, d.status, d.created_at, COUNT(e.id) AS employee_count
    FROM departments d
    LEFT JOIN employees e ON e.department_id = d.id
    GROUP BY d.id
    ORDER BY d.created_at DESC
  `);
  return rows;
}

async function createDepartment(payload) {
  if (usingMockDatabase()) {
    const duplicate = state.departments.find(
      (item) => item.name.toLowerCase() === payload.name.toLowerCase() || item.code.toLowerCase() === payload.code.toLowerCase()
    );
    if (duplicate) {
      throw new Error("Department name or code already exists");
    }

    const item = { id: getNextId("departments"), ...payload, created_at: new Date().toISOString().slice(0, 10) };
    state.departments.push(item);
    return enrichDepartment(item);
  }

  const pool = getPool();
  const [result] = await pool.query(
    "INSERT INTO departments (name, code, manager_name, status) VALUES (?, ?, ?, ?)",
    [payload.name, payload.code, payload.manager_name, payload.status]
  );
  const [rows] = await pool.query("SELECT * FROM departments WHERE id = ?", [result.insertId]);
  return rows[0];
}

async function updateDepartment(id, payload) {
  if (usingMockDatabase()) {
    const item = state.departments.find((department) => department.id === id);
    if (!item) {
      return null;
    }
    Object.assign(item, payload);
    return enrichDepartment(item);
  }

  const pool = getPool();
  await pool.query(
    "UPDATE departments SET name = ?, code = ?, manager_name = ?, status = ? WHERE id = ?",
    [payload.name, payload.code, payload.manager_name, payload.status, id]
  );
  const [rows] = await pool.query("SELECT * FROM departments WHERE id = ?", [id]);
  return rows[0] || null;
}

async function deleteDepartment(id) {
  if (usingMockDatabase()) {
    const index = state.departments.findIndex((item) => item.id === id);
    if (index === -1) {
      return false;
    }
    state.departments.splice(index, 1);
    state.employees.forEach((employee) => {
      if (employee.department_id === id) {
        employee.department_id = null;
      }
    });
    return true;
  }

  const pool = getPool();
  const [result] = await pool.query("DELETE FROM departments WHERE id = ?", [id]);
  return result.affectedRows > 0;
}

async function getEmployees() {
  if (usingMockDatabase()) {
    return sortByCreatedDesc(state.employees.map(enrichEmployee));
  }

  const pool = getPool();
  const [rows] = await pool.query(`
    SELECT e.id, e.full_name, e.email, e.phone, e.department_id, e.status, e.created_at, d.name AS department_name
    FROM employees e
    LEFT JOIN departments d ON d.id = e.department_id
    ORDER BY e.created_at DESC
  `);
  return rows;
}

async function createEmployee(payload) {
  if (usingMockDatabase()) {
    const duplicate = state.employees.find((item) => item.email.toLowerCase() === payload.email.toLowerCase());
    if (duplicate) {
      throw new Error("Employee email already exists");
    }
    const item = { id: getNextId("employees"), ...payload, created_at: new Date().toISOString().slice(0, 10) };
    state.employees.push(item);
    return enrichEmployee(item);
  }

  const pool = getPool();
  const [result] = await pool.query(
    "INSERT INTO employees (full_name, email, phone, department_id, status) VALUES (?, ?, ?, ?, ?)",
    [payload.full_name, payload.email, payload.phone, payload.department_id, payload.status]
  );
  const [rows] = await pool.query(`
    SELECT e.*, d.name AS department_name
    FROM employees e
    LEFT JOIN departments d ON d.id = e.department_id
    WHERE e.id = ?
  `, [result.insertId]);
  return rows[0];
}

async function updateEmployee(id, payload) {
  if (usingMockDatabase()) {
    const item = state.employees.find((employee) => employee.id === id);
    if (!item) {
      return null;
    }
    Object.assign(item, payload);
    return enrichEmployee(item);
  }

  const pool = getPool();
  await pool.query(
    "UPDATE employees SET full_name = ?, email = ?, phone = ?, department_id = ?, status = ? WHERE id = ?",
    [payload.full_name, payload.email, payload.phone, payload.department_id, payload.status, id]
  );
  const [rows] = await pool.query(`
    SELECT e.*, d.name AS department_name
    FROM employees e
    LEFT JOIN departments d ON d.id = e.department_id
    WHERE e.id = ?
  `, [id]);
  return rows[0] || null;
}

async function deleteEmployee(id) {
  if (usingMockDatabase()) {
    const index = state.employees.findIndex((item) => item.id === id);
    if (index === -1) {
      return false;
    }
    state.employees.splice(index, 1);
    state.assets.forEach((asset) => {
      if (asset.assigned_employee_id === id) {
        asset.assigned_employee_id = null;
        asset.status = "Available";
      }
    });
    return true;
  }

  const pool = getPool();
  const [result] = await pool.query("DELETE FROM employees WHERE id = ?", [id]);
  return result.affectedRows > 0;
}

async function getAssets() {
  if (usingMockDatabase()) {
    return sortByCreatedDesc(state.assets.map(enrichAsset));
  }

  const pool = getPool();
  const [rows] = await pool.query(`
    SELECT a.id, a.name, a.asset_tag, a.type, a.status, a.assigned_employee_id, a.purchase_date, a.created_at,
    e.full_name AS assigned_employee_name
    FROM assets a
    LEFT JOIN employees e ON e.id = a.assigned_employee_id
    ORDER BY a.created_at DESC
  `);
  return rows;
}

async function createAsset(payload) {
  if (usingMockDatabase()) {
    const duplicate = state.assets.find((item) => item.asset_tag.toLowerCase() === payload.asset_tag.toLowerCase());
    if (duplicate) {
      throw new Error("Asset tag already exists");
    }
    const item = { id: getNextId("assets"), ...payload, created_at: new Date().toISOString().slice(0, 10) };
    state.assets.push(item);
    return enrichAsset(item);
  }

  const pool = getPool();
  const [result] = await pool.query(
    "INSERT INTO assets (name, asset_tag, type, status, assigned_employee_id, purchase_date) VALUES (?, ?, ?, ?, ?, ?)",
    [payload.name, payload.asset_tag, payload.type, payload.status, payload.assigned_employee_id, payload.purchase_date]
  );
  const [rows] = await pool.query(`
    SELECT a.*, e.full_name AS assigned_employee_name
    FROM assets a
    LEFT JOIN employees e ON e.id = a.assigned_employee_id
    WHERE a.id = ?
  `, [result.insertId]);
  return rows[0];
}

async function updateAsset(id, payload) {
  if (usingMockDatabase()) {
    const item = state.assets.find((asset) => asset.id === id);
    if (!item) {
      return null;
    }
    Object.assign(item, payload);
    return enrichAsset(item);
  }

  const pool = getPool();
  await pool.query(
    "UPDATE assets SET name = ?, asset_tag = ?, type = ?, status = ?, assigned_employee_id = ?, purchase_date = ? WHERE id = ?",
    [payload.name, payload.asset_tag, payload.type, payload.status, payload.assigned_employee_id, payload.purchase_date, id]
  );
  const [rows] = await pool.query(`
    SELECT a.*, e.full_name AS assigned_employee_name
    FROM assets a
    LEFT JOIN employees e ON e.id = a.assigned_employee_id
    WHERE a.id = ?
  `, [id]);
  return rows[0] || null;
}

async function deleteAsset(id) {
  if (usingMockDatabase()) {
    const index = state.assets.findIndex((item) => item.id === id);
    if (index === -1) {
      return false;
    }
    state.assets.splice(index, 1);
    state.maintenance = state.maintenance.filter((item) => item.asset_id !== id);
    return true;
  }

  const pool = getPool();
  const [result] = await pool.query("DELETE FROM assets WHERE id = ?", [id]);
  return result.affectedRows > 0;
}

async function getTechnicians() {
  if (usingMockDatabase()) {
    return sortByCreatedDesc(state.technicians);
  }

  const pool = getPool();
  const [rows] = await pool.query("SELECT * FROM technicians ORDER BY created_at DESC");
  return rows;
}

async function createTechnician(payload) {
  if (usingMockDatabase()) {
    const duplicate = state.technicians.find((item) => item.email.toLowerCase() === payload.email.toLowerCase());
    if (duplicate) {
      throw new Error("Technician email already exists");
    }
    const item = { id: getNextId("technicians"), ...payload, created_at: new Date().toISOString().slice(0, 10) };
    state.technicians.push(item);
    return item;
  }

  const pool = getPool();
  const [result] = await pool.query(
    "INSERT INTO technicians (full_name, email, phone, specialization, status) VALUES (?, ?, ?, ?, ?)",
    [payload.full_name, payload.email, payload.phone, payload.specialization, payload.status]
  );
  const [rows] = await pool.query("SELECT * FROM technicians WHERE id = ?", [result.insertId]);
  return rows[0];
}

async function updateTechnician(id, payload) {
  if (usingMockDatabase()) {
    const item = state.technicians.find((technician) => technician.id === id);
    if (!item) {
      return null;
    }
    Object.assign(item, payload);
    return item;
  }

  const pool = getPool();
  await pool.query(
    "UPDATE technicians SET full_name = ?, email = ?, phone = ?, specialization = ?, status = ? WHERE id = ?",
    [payload.full_name, payload.email, payload.phone, payload.specialization, payload.status, id]
  );
  const [rows] = await pool.query("SELECT * FROM technicians WHERE id = ?", [id]);
  return rows[0] || null;
}

async function deleteTechnician(id) {
  if (usingMockDatabase()) {
    const index = state.technicians.findIndex((item) => item.id === id);
    if (index === -1) {
      return false;
    }
    state.technicians.splice(index, 1);
    state.maintenance = state.maintenance.filter((item) => item.technician_id !== id);
    return true;
  }

  const pool = getPool();
  const [result] = await pool.query("DELETE FROM technicians WHERE id = ?", [id]);
  return result.affectedRows > 0;
}

async function getMaintenance() {
  if (usingMockDatabase()) {
    return sortByCreatedDesc(state.maintenance.map(enrichMaintenance));
  }

  const pool = getPool();
  const [rows] = await pool.query(`
    SELECT m.id, m.asset_id, m.technician_id, m.request_date, m.scheduled_date, m.status, m.notes, m.created_at,
    a.name AS asset_name, t.full_name AS technician_name
    FROM maintenance m
    LEFT JOIN assets a ON a.id = m.asset_id
    LEFT JOIN technicians t ON t.id = m.technician_id
    ORDER BY m.created_at DESC
  `);
  return rows;
}

async function createMaintenance(payload) {
  if (usingMockDatabase()) {
    const item = { id: getNextId("maintenance"), ...payload, created_at: new Date().toISOString().slice(0, 10) };
    state.maintenance.push(item);
    return enrichMaintenance(item);
  }

  const pool = getPool();
  const [result] = await pool.query(
    "INSERT INTO maintenance (asset_id, technician_id, request_date, scheduled_date, status, notes) VALUES (?, ?, ?, ?, ?, ?)",
    [payload.asset_id, payload.technician_id, payload.request_date, payload.scheduled_date, payload.status, payload.notes]
  );
  const [rows] = await pool.query(`
    SELECT m.*, a.name AS asset_name, t.full_name AS technician_name
    FROM maintenance m
    LEFT JOIN assets a ON a.id = m.asset_id
    LEFT JOIN technicians t ON t.id = m.technician_id
    WHERE m.id = ?
  `, [result.insertId]);
  return rows[0];
}

async function updateMaintenance(id, payload) {
  if (usingMockDatabase()) {
    const item = state.maintenance.find((record) => record.id === id);
    if (!item) {
      return null;
    }
    Object.assign(item, payload);
    return enrichMaintenance(item);
  }

  const pool = getPool();
  await pool.query(
    "UPDATE maintenance SET asset_id = ?, technician_id = ?, request_date = ?, scheduled_date = ?, status = ?, notes = ? WHERE id = ?",
    [payload.asset_id, payload.technician_id, payload.request_date, payload.scheduled_date, payload.status, payload.notes, id]
  );
  const [rows] = await pool.query(`
    SELECT m.*, a.name AS asset_name, t.full_name AS technician_name
    FROM maintenance m
    LEFT JOIN assets a ON a.id = m.asset_id
    LEFT JOIN technicians t ON t.id = m.technician_id
    WHERE m.id = ?
  `, [id]);
  return rows[0] || null;
}

async function deleteMaintenance(id) {
  if (usingMockDatabase()) {
    const index = state.maintenance.findIndex((item) => item.id === id);
    if (index === -1) {
      return false;
    }
    state.maintenance.splice(index, 1);
    return true;
  }

  const pool = getPool();
  const [result] = await pool.query("DELETE FROM maintenance WHERE id = ?", [id]);
  return result.affectedRows > 0;
}

module.exports = {
  authenticateUser,
  createAsset,
  createDepartment,
  createEmployee,
  createMaintenance,
  createTechnician,
  deleteAsset,
  deleteDepartment,
  deleteEmployee,
  deleteMaintenance,
  deleteTechnician,
  getAssets,
  getDashboardStats,
  getDepartments,
  getEmployees,
  getMaintenance,
  getTechnicians,
  updateAsset,
  updateDepartment,
  updateEmployee,
  updateMaintenance,
  updateTechnician,
};
