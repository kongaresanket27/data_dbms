const sessions = new Map();

function issueToken(user) {
  const token = `token-${user.username}-${Date.now()}`;
  sessions.set(token, {
    id: user.id,
    username: user.username,
    full_name: user.full_name,
    role: user.role,
  });
  return token;
}

function authenticate(req, res, next) {
  const token = req.headers["x-auth-token"];
  if (!token || !sessions.has(token)) {
    return res.status(401).json({ message: "Unauthorized. Please log in first." });
  }

  req.user = sessions.get(token);
  next();
}

module.exports = {
  authenticate,
  issueToken,
};
