const express = require("express");
const {
  listAssets,
  addAsset,
  editAsset,
  removeAsset,
} = require("../controllers/assetController");

const router = express.Router();

router.get("/", listAssets);
router.post("/", addAsset);
router.put("/:id", editAsset);
router.delete("/:id", removeAsset);

module.exports = router;
