const express = require("express");
const {
  listEmployees,
  addEmployee,
  editEmployee,
  removeEmployee,
} = require("../controllers/employeeController");

const router = express.Router();

router.get("/", listEmployees);
router.post("/", addEmployee);
router.put("/:id", editEmployee);
router.delete("/:id", removeEmployee);

module.exports = router;
