const express = require("express");
const {
  listTechnicians,
  addTechnician,
  editTechnician,
  removeTechnician,
} = require("../controllers/technicianController");

const router = express.Router();

router.get("/", listTechnicians);
router.post("/", addTechnician);
router.put("/:id", editTechnician);
router.delete("/:id", removeTechnician);

module.exports = router;
