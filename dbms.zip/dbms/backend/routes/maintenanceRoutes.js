const express = require("express");
const {
  listMaintenance,
  addMaintenance,
  editMaintenance,
  removeMaintenance,
} = require("../controllers/maintenanceController");

const router = express.Router();

router.get("/", listMaintenance);
router.post("/", addMaintenance);
router.put("/:id", editMaintenance);
router.delete("/:id", removeMaintenance);

module.exports = router;
