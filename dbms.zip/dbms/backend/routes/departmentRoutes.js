const express = require("express");
const {
  listDepartments,
  addDepartment,
  editDepartment,
  removeDepartment,
} = require("../controllers/departmentController");

const router = express.Router();

router.get("/", listDepartments);
router.post("/", addDepartment);
router.put("/:id", editDepartment);
router.delete("/:id", removeDepartment);

module.exports = router;
